#include <stdio.h>
int main()
{
  int x, y;

  printf("Enter two numbers \n");
  scanf("%d%d", &x, &y);

  int add = x + y;
  int sub = x - y;
  int mul = x * y;  

  printf("Addition of the numbers = %d\n", add);
  printf("Substraction of the numbers = %d\n", sub);
  printf("multiplication of the numbers = %d\n", mul);

  return 0;
}


