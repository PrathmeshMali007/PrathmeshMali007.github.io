<?php

$con = mysqli_connect('localhost','root','','onlinejob');
if (!$con) {
	die(' Database cannot established');
 }


?>