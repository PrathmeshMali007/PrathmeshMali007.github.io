<footer>
	<div class="container position-absolute">
		Copyright <span class="glyphicon glyphicon-copyright-mark"></span> PrathmeshTech.
		All Rights Reserved | Contact Us: +91 77768 61695
	</div>
</footer>